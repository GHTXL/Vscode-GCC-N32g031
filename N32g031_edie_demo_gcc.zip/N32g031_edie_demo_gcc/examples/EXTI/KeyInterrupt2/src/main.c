/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file main.c
 * @author Nations 
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "main.h"
#include <stdio.h>
#include <stdint.h>




/**
 * @brief  Main program.
 */
int main(void)
{
	
    /*SystemInit() function has been called by startup file startup_n32g031.s*/

    /*Initialize Led1 and Led2 as output pushpull mode*/
    LedInit(LED1_PORT, LED1_PIN);
    LedInit(LED2_PORT, LED2_PIN);
	

		USART_config(USART1);
//		USART_config(USART2);
	
		MD7672_Init(POWER_EN_PORT,POWER_EN_PIN);
		
    /*Initialize key as external line interrupt*/
    KeyInputExtiInit(KEY_INPUT_PORT, KEY_INPUT_PIN);

    /*Turn on Led1*/
    LedOn(LED1_PORT, LED1_PIN);
	
		printf("kick off key input interrupt test\r\n");
		
    while (1)
    {
			
			
    }
}

/**
 * @brief  Inserts a delay time.
 * @param count specifies the delay time length.
 */
void Delay(uint32_t count)
{
    for (; count > 0; count--)
        ;
}
/**
 * @brief  Configures key port.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void KeyInputExtiInit(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;

    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));

    /* Enable the GPIO Clock */
    if (GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_AFIO, ENABLE);  //enable GPIO & AFIO clock
    }
    else if (GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB | RCC_APB2_PERIPH_AFIO, ENABLE);
    }
    else if (GPIOx == GPIOC)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC | RCC_APB2_PERIPH_AFIO, ENABLE);
    }
    else if (GPIOx == GPIOF)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF | RCC_APB2_PERIPH_AFIO, ENABLE);
    }
    else
    {
        return;
    }

    /*Configure the GPIO pin as input floating*/
    if (Pin <= GPIO_PIN_ALL)
    {
        GPIO_InitStruct(&GPIO_InitStructure);
        GPIO_InitStructure.Pin          = Pin;
        GPIO_InitStructure.GPIO_Pull    = GPIO_NO_PULL;//GPIO_PULL_DOWN  GPIO_PULL_UP
			
				GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    }

    /*Configure key EXTI Line to key input Pin*/
		GPIO_ConfigEXTILine(KEY_INPUT_PORT_SOURCE, KEY_INPUT_PIN_SOURCE);

    /*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line    = KEY_INPUT_EXTI_LINE;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; // EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
		
		EXTI_InitPeripheral(&EXTI_InitStructure);

    /*Set key input interrupt priority*/
    NVIC_InitStructure.NVIC_IRQChannel                   = KEY_INPUT_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPriority           = 1;
		NVIC_InitStructure.NVIC_IRQChannelPriority           = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
		
		NVIC_Init(&NVIC_InitStructure);
}
/**
 * @brief  Configures LED GPIO.
 * @param Led Specifies the Led to be configured.
 *   This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedInit(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;

    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));

    /* Enable the GPIO Clock */
    if (GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    }
    else if (GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    }
    else if (GPIOx == GPIOC)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    }
    else if (GPIOx == GPIOF)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);
    }
    else
    {
        return;
    }

    /* Configure the GPIO pin as output push-pull */
    if (Pin <= GPIO_PIN_ALL)
    {
        GPIO_InitStruct(&GPIO_InitStructure);
        GPIO_InitStructure.Pin = Pin;
        GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
			
        GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    }
}



/**
 * @brief  Turns selected Led on.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOn(GPIO_Module* GPIOx, uint16_t Pin)
{    
    GPIO_SetBits(GPIOx, Pin);
}

/**
 * @brief  Turns selected Led Off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOff(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_ResetBits(GPIOx, Pin);
}

/**
 * @brief  Toggles the selected Led.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedBlink(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_TogglePin(GPIOx, Pin);
}


/**
 * @brief  Configures MD7672 GPIO.
 * @param MD7672 Specifies the Enable pin to be configured.
 *   This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void MD7672_Init(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;

    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));

    /* Enable the GPIO Clock */
    if (GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    }
    else if (GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    }
    else if (GPIOx == GPIOC)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    }
    else if (GPIOx == GPIOF)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);
    }
    else
    {
        return;
    }

    /* Configure the GPIO pin as output push-pull */
    if (Pin <= GPIO_PIN_ALL)
    {
        GPIO_InitStruct(&GPIO_InitStructure);
        GPIO_InitStructure.Pin = Pin;
        GPIO_InitStructure.GPIO_Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    }
		MD7672_disable();
}

void MD7672_enable(void)
{

	GPIO_SetBits(POWER_EN_PORT,POWER_EN_PIN);

}

void MD7672_disable(void)
{

	GPIO_ResetBits(POWER_EN_PORT,POWER_EN_PIN);

}


void USART_config(USART_Module* USARTx)
{
		GPIO_InitType GPIO_InitStructure;
		USART_InitType USART_InitStructure;

//	    /* Initialize GPIO_InitStructure */
//    GPIO_InitStruct(&GPIO_InitStructure);
	
		if(USARTx==USART1)
				{
						
				RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA|RCC_APB2_PERIPH_USART1, ENABLE);  //USART1 clock &GPIOA Clock

			
				/* Configure USARTx Tx as alternate function push-pull */
				GPIO_InitStructure.Pin            = USART1_TxPin;      
				GPIO_InitStructure.GPIO_Mode      = GPIO_MODE_AF_PP;
				GPIO_InitStructure.GPIO_Alternate = USART1_Tx_GPIO_AF;	
			
				GPIO_InitPeripheral(USART1_GPIO, &GPIO_InitStructure);   

				/* Configure USARTx Rx as alternate function push-pull */
				GPIO_InitStructure.Pin            = USART1_RxPin;				
		//	  GPIO_InitStructure.GPIO_Mode      = GPIO_MODE_AF_OD;
				GPIO_InitStructure.GPIO_Alternate = USART1_Rx_GPIO_AF;	
			
				GPIO_InitPeripheral(USART1_GPIO, &GPIO_InitStructure); 
				
				}
		else
			{
				RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);  //GPIOA Clock
				RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_USART2, ENABLE);  //USART2 clock
				
				/* Configure USARTx Tx as alternate function push-pull */
				GPIO_InitStructure.Pin            = USART2_TxPin;      
				GPIO_InitStructure.GPIO_Mode      = GPIO_MODE_AF_PP;
				GPIO_InitStructure.GPIO_Alternate = USART2_Tx_GPIO_AF;	
			
				GPIO_InitPeripheral(USART2_GPIO, &GPIO_InitStructure);   

				/* Configure USARTx Rx as alternate function push-pull */
				GPIO_InitStructure.Pin            = USART2_RxPin;				
		//	  GPIO_InitStructure.GPIO_Mode      = GPIO_MODE_AF_OD;
				GPIO_InitStructure.GPIO_Alternate = USART2_Rx_GPIO_AF;	
			
				GPIO_InitPeripheral(USART2_GPIO, &GPIO_InitStructure); 
				
				}

			USART_InitStructure.BaudRate            = 115200;
			USART_InitStructure.WordLength          = USART_WL_8B;
			USART_InitStructure.StopBits            = USART_STPB_1;
			USART_InitStructure.Parity              = USART_PE_NO;
			USART_InitStructure.HardwareFlowControl = USART_HFCTRL_NONE;
			USART_InitStructure.Mode                = USART_MODE_RX | USART_MODE_TX;
	
//		USART_Init(USART1,&USART_InitStructure);
//		USART_Init(USART2,&USART_InitStructure);
		USART_Init(USARTx,&USART_InitStructure);

//		USART_Enable(USART1,ENABLE);
//		USART_Enable(USART2,ENABLE);
		USART_Enable(USARTx,ENABLE);
		
}

/**
 * @brief  Retargets the C library printf function to the USART1.
 * @param
 * @return
 */
int fputc(int ch, FILE* f)
{
    USART_SendData(USART1, (uint8_t)ch);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXDE) == RESET)
        ;
    return (ch);
}

/*  */
/**
 * @brief  Retargets the C library scanf function to the USART1.
 * @param
 * @return
 */
int fgetc(FILE* f)
{
    while (USART_GetFlagStatus(USART2, USART_FLAG_RXDNE) == RESET)
        ;
    return (int)USART_ReceiveData(USART2);
}

/**
 * @brief Assert failed function by user.
 * @param file The name of the call that failed.
 * @param line The source line number of the call that failed.
 */
#ifdef USE_FULL_ASSERT
void assert_failed(const uint8_t* expr, const uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif // USE_FULL_ASSERT
/**
 * @}
 */
