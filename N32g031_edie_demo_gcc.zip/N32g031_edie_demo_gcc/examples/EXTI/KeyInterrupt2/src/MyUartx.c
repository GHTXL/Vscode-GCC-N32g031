#include "MyUartx.h"

//UARTx_config();

void MYUSART_Init(USART_Module* USARTx, USART_InitType* USART_InitStruct)