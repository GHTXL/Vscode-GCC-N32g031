#ifndef __MYUARTX_H__
#define __MYUARTX_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "n32g031.h"



#define UART1_PORT  		GPIOA
#define UART1_TX_PIN		GPIO_PIN_9
#define UART1_RX_PIN		GPIO_PIN_10	
#define UART1_Clock			RCC_APB2_PERIPH_USART1



#define UART2_PORT  		GPIOA
#define UART2_TX_PIN		GPIO_PIN_2
#define UART2_RX_PIN		GPIO_PIN_3
#define UART2_Clock			RCC_APB1_PERIPH_USART2


#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H__ */